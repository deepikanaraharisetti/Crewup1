'use client';

import { collection, query, where } from 'firebase/firestore';
import { useFirestore, useUser, useCollection, useMemoFirebase } from '@/firebase';
import { Opportunity } from '@/lib/types';
import OpportunityCard from '@/components/opportunity-card';
import LoadingSpinner from '@/components/loading-spinner';
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';

export default function MyProjectsPage() {
  const { user, isUserLoading: authLoading } = useUser();
  const firestore = useFirestore();
  
  const opportunitiesQuery = useMemoFirebase(() =>
    !authLoading && user && firestore
      ? query(collection(firestore, "opportunities"), where("ownerId", "==", user.uid))
      : null
  , [user, firestore, authLoading]);

  const { data: opportunities, isLoading: opportunitiesLoading, error: opportunitiesError } = useCollection<Opportunity>(opportunitiesQuery);
  
  const [displayedOpportunities, setDisplayedOpportunities] = useState<Opportunity[]>([]);
  
  useEffect(() => {
    if (opportunities) {
      setDisplayedOpportunities(opportunities);
    }
  }, [opportunities]);

  const handleOpportunityDeleted = (opportunityId: string) => {
    setDisplayedOpportunities(prev => prev.filter(op => op.id !== opportunityId));
  };
  
  const loading = opportunitiesLoading || authLoading;

  if (loading) {
    return <LoadingSpinner fullScreen />;
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl">My Projects</CardTitle>
          <CardDescription>Manage your created opportunities and review join requests on each project's page.</CardDescription>
        </CardHeader>
      </Card>
      
      {opportunitiesError && <p className='text-destructive'>Error: {opportunitiesError.message}</p>}

      <Card>
        <CardHeader>
            <CardTitle>Created Projects ({displayedOpportunities?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
        {displayedOpportunities && displayedOpportunities.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {displayedOpportunities.map(opportunity => (
                <OpportunityCard key={opportunity.id} opportunity={opportunity} onDeleted={handleOpportunityDeleted} />
              ))}
            </div>
        ) : (
          <div className="text-center py-12">
              <h3 className="text-lg font-medium">You haven't created any projects yet.</h3>
              <p className="text-muted-foreground mt-2">Get started by creating a new opportunity!</p>
              <Button asChild className="mt-4">
                <Link href="/opportunities/create">Create Opportunity</Link>
              </Button>
          </div>
        )}
        </CardContent>
      </Card>
    </div>
  );
}
