'use client';

import { use, useMemo } from 'react';
import { doc, query, where, collection } from 'firebase/firestore';
import { useFirestore, useUser, useDoc, useCollection, useMemoFirebase } from '@/firebase';
import { UserProfile, Opportunity } from '@/lib/types';
import LoadingSpinner from '@/components/loading-spinner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import OpportunityCard from '@/components/opportunity-card';
import { Button } from '@/components/ui/button';
import { Pencil } from 'lucide-react';
import Link from 'next/link';

function UserProfileClient({ uid }: { uid: string }) {
  const { user: authUser, isUserLoading: authLoading } = useUser();
  const firestore = useFirestore();

  const profileRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return doc(firestore, 'users', uid);
  }, [firestore, uid]);
  
  const { data: profile, isLoading: profileLoading, error: profileError } = useDoc<UserProfile>(profileRef);

  const ownedQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return query(collection(firestore, "opportunities"), where("ownerId", "==", uid));
  }, [firestore, uid]);

  const memberQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return query(collection(firestore, "opportunities"), where("teamMemberIds", "array-contains", uid));
  }, [firestore, uid]);

  const { data: ownedOpportunities, isLoading: ownedLoading } = useCollection<Opportunity>(ownedQuery);
  const { data: memberOpportunities, isLoading: memberLoading } = useCollection<Opportunity>(memberQuery);

  const projects = useMemo(() => {
    const userProjectsMap = new Map<string, Opportunity>();

    (ownedOpportunities || []).forEach(doc => {
      userProjectsMap.set(doc.id, doc);
    });

    (memberOpportunities || []).forEach(doc => {
      if (!userProjectsMap.has(doc.id)) {
        userProjectsMap.set(doc.id, doc);
      }
    });
    
    return Array.from(userProjectsMap.values());
  }, [ownedOpportunities, memberOpportunities]);

  const isOwner = authUser?.uid === uid;
  const loading = authLoading || profileLoading || ownedLoading || memberLoading;

  if (loading) return <LoadingSpinner fullScreen />;

  if (profileError || !profile) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>User Not Found</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">This user may not have a profile yet or it could not be loaded.</p>
          {profileError && <p className='text-destructive mt-2'>Error: {profileError.message}</p>}
          {isOwner && !profile && (
            <Button asChild className="mt-4">
              <Link href="/profile">Create Your Profile</Link>
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      <Card className="overflow-hidden">
        <div className="bg-muted h-24" />
        <CardHeader className="px-6 pt-4">
            <div className="flex items-baseline gap-4">
                <h1 className="text-3xl font-bold tracking-tight">{profile.displayName}</h1>
                {isOwner && (
                    <Button variant="outline" size="sm" asChild>
                        <Link href="/profile">
                            <Pencil className="mr-2 h-3 w-3"/> Edit Profile
                        </Link>
                    </Button>
                )}
            </div>
            <p className="text-muted-foreground">{profile.email}</p>
        </CardHeader>
        <CardContent className="space-y-6">
            <div>
                <h3 className="font-semibold text-lg mb-2">Bio</h3>
                <p className="text-muted-foreground whitespace-pre-wrap">{profile.bio || 'No bio provided.'}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div>
                    <h3 className="font-semibold text-lg mb-2">Skills</h3>
                    <div className="flex flex-wrap gap-2">
                    {profile.skills && profile.skills.length > 0 ? (
                        profile.skills.map(skill => <Badge key={skill} variant="secondary">{skill}</Badge>)
                    ) : (
                        <p className="text-sm text-muted-foreground">No skills listed.</p>
                    )}
                    </div>
                </div>
                <div>
                    <h3 className="font-semibold text-lg mb-2">Interests</h3>
                    <div className="flex flex-wrap gap-2">
                    {profile.interests && profile.interests.length > 0 ? (
                        profile.interests.map(interest => <Badge key={interest} variant="secondary">{interest}</Badge>)
                    ) : (
                        <p className="text-sm text-muted-foreground">No interests listed.</p>
                    )}
                    </div>
                </div>
            </div>
        </CardContent>
      </Card>
      
      <div>
        <h2 className="text-2xl font-semibold tracking-tight mb-4">Projects ({projects.length})</h2>
        {projects.length > 0 ? (
             <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {projects.map(opportunity => (
                    <OpportunityCard key={opportunity.id} opportunity={opportunity} />
                ))}
            </div>
        ) : (
             <Card className="text-center py-12">
                <CardContent>
                    <p className="text-muted-foreground">{profile.displayName} is not yet part of any projects.</p>
                </CardContent>
            </Card>
        )}
      </div>

    </div>
  );
}

export default function UserProfilePage({ params }: { params: Promise<{ uid: string }> }) {
  const { uid } = use(params);
  return <UserProfileClient key={uid} uid={uid} />;
}
