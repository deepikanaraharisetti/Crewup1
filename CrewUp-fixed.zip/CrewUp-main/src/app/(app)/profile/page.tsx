'use client';

import { useUser, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import ProfileForm from '@/components/profile-form';
import LoadingSpinner from '@/components/loading-spinner';
import { UserProfile } from '@/lib/types';
import { doc } from 'firebase/firestore';

export default function ProfilePage() {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();

  const profileRef = useMemoFirebase(() => 
    user ? doc(firestore, 'users', user.uid) : null
  , [user, firestore]);
  
  const { data: userProfile, isLoading: profileLoading } = useDoc<UserProfile>(profileRef);

  const loading = isUserLoading || profileLoading;

  if (loading) {
    return <LoadingSpinner fullScreen />;
  }

  // If there's a user but no profile document yet, we can pass an empty shell
  // to the ProfileForm to create a new profile.
  const profileData = userProfile || {
    uid: user?.uid || '',
    displayName: user?.displayName || '',
    email: user?.email || '',
    photoURL: user?.photoURL || null,
    bio: '',
    skills: [],
    interests: [],
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Edit Your Profile</h1>
        <p className="text-muted-foreground">Manage your personal information, skills, and interests.</p>
      </div>
      <ProfileForm userProfile={profileData} />
    </div>
  );
}
