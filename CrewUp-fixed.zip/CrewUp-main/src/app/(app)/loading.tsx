
import LoadingSpinner from "@/components/loading-spinner";

export default function Loading() {
  return <LoadingSpinner fullScreen />;
}
