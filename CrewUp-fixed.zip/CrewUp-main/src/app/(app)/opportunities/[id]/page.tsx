
'use client';

import { use, useState, useEffect } from 'react';
import Link from 'next/link';
import { doc, arrayUnion, serverTimestamp, collection, setDoc, writeBatch, getDoc } from 'firebase/firestore';
import { useFirestore, useUser, errorEmitter, FirestorePermissionError, useMemoFirebase, useDoc, useCollection } from '@/firebase';
import { Opportunity, UserProfile, JoinRequest } from '@/lib/types';

import LoadingSpinner from '@/components/loading-spinner';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Briefcase, FileText, MessageSquare, PlusCircle, Check, X, UserCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import OpportunityChat from '@/components/opportunity-chat';
import OpportunityFiles from '@/components/opportunity-files';


export default function OpportunityDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();
  
  const opportunityRef = useMemoFirebase(() => firestore && !isUserLoading ? doc(firestore, 'opportunities', id) : null, [firestore, id, isUserLoading]);
  const { data: opportunity, isLoading: opportunityLoading, error: opportunityError } = useDoc<Opportunity>(opportunityRef);

  const isOwner = !opportunityLoading && !!user && !!opportunity && opportunity?.ownerId === user?.uid;

  const joinRequestsQuery = useMemoFirebase(() => {
    // IMPORTANT: Only create the query if we have the opportunity and the user is the owner
    if (firestore && opportunity && isOwner) {
      return collection(firestore, 'opportunities', opportunity.id, 'joinRequests');
    }
    return null; 
  }, [firestore, opportunity, isOwner]);

  const { data: joinRequests, isLoading: joinRequestsLoading, error: joinRequestsError } = useCollection<JoinRequest>(joinRequestsQuery);
  
  const [hasRequested, setHasRequested] = useState(false);
  const [isCheckingRequest, setIsCheckingRequest] = useState(true);

  useEffect(() => {
    const checkRequest = async () => {
      if (firestore && user && opportunity && !isOwner) {
        setIsCheckingRequest(true);
        const requestRef = doc(firestore, 'opportunities', opportunity.id, 'joinRequests', user.uid);
        try {
          const requestSnap = await getDoc(requestRef);
          setHasRequested(requestSnap.exists());
        } catch (serverError: any) {
           if (serverError.code === 'permission-denied') {
             setHasRequested(false);
           } else {
             const permissionError = new FirestorePermissionError({
                path: requestRef.path,
                operation: 'get',
             });
             errorEmitter.emit('permission-error', permissionError);
           }
        } finally {
          setIsCheckingRequest(false);
        }
      } else {
        setIsCheckingRequest(false);
      }
    };
    checkRequest();
  }, [firestore, opportunity, user, isOwner]);


  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleJoinRequest = () => {
    if (!user || !opportunity || !firestore) return;
    setIsSubmitting(true);
    
    if (!user.uid || user.displayName === null || user.email === null) {
        toast({ title: "Incomplete Profile", description: "Your profile is missing information needed to send a request.", variant: "destructive" });
        setIsSubmitting(false);
        return;
    }
    
    const userProfileData: UserProfile = {
      uid: user.uid,
      displayName: user.displayName,
      email: user.email,
      photoURL: user.photoURL,
    };
    
    const requestData = {
      id: user.uid,
      userProfile: userProfileData,
      requestDate: serverTimestamp(),
    };

    const requestRef = doc(firestore, 'opportunities', id, 'joinRequests', user.uid);

    setDoc(requestRef, requestData)
      .then(() => {
        toast({ title: "Request Sent!", description: "The project owner has been notified of your interest." });
        setHasRequested(true);
      })
      .catch((serverError) => {
        const permissionError = new FirestorePermissionError({
            path: requestRef.path,
            operation: 'create',
            requestResourceData: requestData,
        });
        errorEmitter.emit('permission-error', permissionError);
      })
      .finally(() => {
        setIsSubmitting(false);
      });
  };

  const handleRequestAction = (request: JoinRequest, action: 'accept' | 'decline') => {
    if (!user || !opportunity || !firestore) return;

    const batch = writeBatch(firestore);
    const requestRef = doc(firestore, 'opportunities', id, 'joinRequests', request.id);
    batch.delete(requestRef);
    
    let oppUpdateData: any = {};
    let teamUpdateData: any = {};
    let teamRef: any = null;
    const oppRef = doc(firestore, 'opportunities', id);
    
    if (action === 'accept' && opportunity.teamId) {
        teamRef = doc(firestore, 'teams', opportunity.teamId);
        
        const applicantProfileForAddition = { 
            uid: request.userProfile.uid,
            displayName: request.userProfile.displayName,
            email: request.userProfile.email,
            photoURL: request.userProfile.photoURL,
        };
        oppUpdateData = {
            teamMembers: arrayUnion(applicantProfileForAddition),
            teamMemberIds: arrayUnion(request.userProfile.uid)
        };
        batch.update(oppRef, oppUpdateData);

        teamUpdateData = { memberIds: arrayUnion(request.userProfile.uid) };
        batch.update(teamRef, teamUpdateData);
    }

    batch.commit().then(() => {
        if(action === 'accept') {
            toast({ title: 'Member Added', description: `${request.userProfile.displayName} is now on the team.` });
        } else {
            toast({ title: 'Request Declined', description: `You have declined the request from ${request.userProfile.displayName}.` });
        }
    }).catch((serverError) => {
        let errorPath: string;
        let errorOperation: 'update' | 'delete' | 'create';
        let errorData: any | undefined = undefined;

        if (action === 'accept') {
            errorPath = teamRef ? teamRef.path : oppRef.path;
            errorOperation = 'update';
            errorData = teamRef ? teamUpdateData : oppUpdateData;
        } else { 
            errorPath = requestRef.path;
            errorOperation = 'delete';
        }

        const permissionError = new FirestorePermissionError({
            path: errorPath,
            operation: errorOperation,
            requestResourceData: errorData,
        });
        errorEmitter.emit('permission-error', permissionError);
        
        toast({
            title: 'Action Failed',
            description: 'Could not complete the action. Please check permissions and try again.',
            variant: 'destructive',
        });
    });
  }


  const isMember = (isOwner || opportunity?.teamMemberIds?.includes(user?.uid || '')) && !!opportunity?.teamId;
  
  const getInitials = (name: string | null | undefined): string => {
    if (!name) return '??';
    return name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase();
  };

  const getJoinButton = () => {
    if (!user) return <Button className="w-full" size="lg" asChild><Link href="/login">Login to Join</Link></Button>;
    if (isMember) return <Button className="w-full" size="lg" disabled><UserCheck className="mr-2"/>You're on the team</Button>;
    if (hasRequested) return <Button className="w-full" size="lg" disabled variant="outline">Request Sent</Button>;
    if (isOwner && !opportunity?.teamId) return <Button className="w-full" size="lg" disabled variant="outline">Collaboration Disabled</Button>;
    if (isOwner) return <Button className="w-full" size="lg" disabled variant="outline">You are the owner</Button>;
    return (
        <Button className="w-full" size="lg" onClick={handleJoinRequest} disabled={isSubmitting || isCheckingRequest}>
            {isSubmitting || isCheckingRequest ? <LoadingSpinner /> : <> <PlusCircle className="mr-2"/> Request to Join</>}
        </Button>
    );
  };
  
  const loading = opportunityLoading || isUserLoading || (isOwner && joinRequestsLoading);

  if (loading) return <LoadingSpinner fullScreen />;
  if (opportunityError) return <div className="text-center py-12">Error loading opportunity: {opportunityError.message}</div>;
  if (!opportunity) return <div className="text-center py-12">Opportunity not found. It may have been deleted.</div>;
  
  const showCollaborationTabs = isMember && opportunity.teamId && (opportunity.chatEnabled || opportunity.filesEnabled);

  // Safely handle null joinRequests to prevent crashes
  const validJoinRequests = (joinRequests || []).filter(req => req && req.userProfile);

  return (
    <div className="grid gap-8 lg:grid-cols-3">
      <div className="lg:col-span-2 space-y-8">
        <Card>
          <CardHeader>
             <h1 className="text-3xl font-bold tracking-tight">{opportunity.title}</h1>
             <p className="text-muted-foreground">
                Project posted by <Link href={`/users/${opportunity.ownerId}`} className="font-medium text-card-foreground hover:underline">{opportunity.ownerName}</Link>
             </p>
          </CardHeader>
          <CardContent>
            <p className="text-base whitespace-pre-wrap leading-relaxed">{opportunity.description}</p>
          </CardContent>
        </Card>

        {isOwner && (
            <Card>
                <CardHeader>
                    <CardTitle>Join Requests ({validJoinRequests.length})</CardTitle>
                    <CardDescription>Review users who want to join your team.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                    {joinRequestsLoading ? (
                      <LoadingSpinner />
                    ) : joinRequestsError ? (
                        <div className="text-center text-destructive-foreground bg-destructive/80 p-4 rounded-md">
                            <p>Error loading join requests.</p>
                            <p className="text-sm">{joinRequestsError.message}</p>
                        </div>
                    ) : validJoinRequests.length > 0 ? (
                      validJoinRequests.map(request => (
                        <div key={request.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                            <div className="flex items-center gap-4">
                                <Link href={`/users/${request.userProfile.uid}`}>
                                    <Avatar>
                                        <AvatarImage src={request.userProfile.photoURL || ''} />
                                        <AvatarFallback>{getInitials(request.userProfile.displayName)}</AvatarFallback>
                                    </Avatar>
                                </Link>
                                <div>
                                    <Link href={`/users/${request.userProfile.uid}`} className="font-semibold hover:underline">{request.userProfile.displayName}</Link>
                                </div>
                            </div>
                            <div className="flex gap-2">
                                <Button size="icon" variant="outline" className="text-green-600 hover:bg-green-100 hover:text-green-700 dark:hover:bg-green-900/50" onClick={() => handleRequestAction(request, 'accept')}><Check className="w-4 h-4"/></Button>
                                <Button size="icon" variant="outline" className="text-red-600 hover:bg-red-100 hover:text-red-700 dark:hover-bg-red-900/50" onClick={() => handleRequestAction(request, 'decline')}><X className="w-4 h-4"/></Button>
                            </div>
                        </div>
                      ))
                    ) : (
                      <p className='text-sm text-muted-foreground text-center py-4'>No pending join requests.</p>
                    )}
                </CardContent>
            </Card>
        )}


        {showCollaborationTabs && (
          <Tabs defaultValue={opportunity.chatEnabled ? 'chat' : 'files'} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                  {opportunity.chatEnabled && <TabsTrigger value="chat"><MessageSquare className="w-4 h-4 mr-2"/>Chat</TabsTrigger>}
                  {opportunity.filesEnabled && <TabsTrigger value="files"><FileText className="w-4 h-4 mr-2"/>Files</TabsTrigger>}
              </TabsList>
              {opportunity.chatEnabled && (
                <TabsContent value="chat">
                    <OpportunityChat opportunity={opportunity} isMember={isMember} />
                </TabsContent>
              )}
              {opportunity.filesEnabled && (
                <TabsContent value="files">
                    <OpportunityFiles opportunity={opportunity} isMember={isMember} />
                </TabsContent>
              )}
          </Tabs>
        )}

      </div>
      <div className="lg:col-span-1 space-y-6">
        <Card>
          <CardContent className="p-6">
            {getJoinButton()}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Briefcase className="w-5 h-5"/>Needed Skills & Roles</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2 text-sm tracking-tight">Skills</h4>
              <div className="flex flex-wrap gap-2">
                {opportunity.requiredSkills.map(skill => (
                  <Badge key={skill} variant="secondary">{skill}</Badge>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-sm tracking-tight">Roles</h4>
              <div className="flex flex-wrap gap-2">
                {opportunity.roles.map(role => (
                  <Badge key={role}>{role}</Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5"/>Team Members ({opportunity.teamMembers.length + 1})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link href={`/users/${opportunity.ownerId}`} className="flex items-center gap-3 hover:bg-accent p-2 rounded-md">
              <Avatar>
                <AvatarImage src={opportunity.ownerPhotoURL} />
                <AvatarFallback>{getInitials(opportunity.ownerName)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold">{opportunity.ownerName}</p>
                <p className="text-sm text-muted-foreground">Project Owner</p>
              </div>
            </Link>
            {opportunity.teamMembers.map(member => (
              <Link href={`/users/${member.uid}`} key={member.uid} className="flex items-center gap-3 hover:bg-accent p-2 rounded-md">
                <Avatar>
                  <AvatarImage src={member.photoURL || ''} />
                  <AvatarFallback>{getInitials(member.displayName)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">{member.displayName}</p>
                  <p className="text-sm text-muted-foreground">Team Member</p>
                </div>
              </Link>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
