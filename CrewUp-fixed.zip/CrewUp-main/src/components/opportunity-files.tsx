
'use client';

import { useState, useEffect, useRef } from 'react';
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot, doc, FirestoreError, setDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, getStorage, type FirebaseStorage } from 'firebase/storage';
import { useFirestore, useUser, errorEmitter, FirestorePermissionError, useFirebaseApp } from '@/firebase';
import { ProjectFile, Opportunity } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import LoadingSpinner from './loading-spinner';
import { format } from 'date-fns';
import { Upload, File, Download, Lock } from 'lucide-react';
import { firebaseConfig } from '@/firebase/config';

interface OpportunityFilesProps {
  opportunity: Opportunity;
  isMember: boolean;
}

export default function OpportunityFiles({ opportunity, isMember }: OpportunityFilesProps) {
  const { user } = useUser();
  const firestore = useFirestore();
  const firebaseApp = useFirebaseApp(); 
  const { toast } = useToast();
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<FirestoreError | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { teamId } = opportunity;
  const [storage, setStorage] = useState<FirebaseStorage | null>(null);

  useEffect(() => {
    if (firebaseApp) {
      setStorage(getStorage(firebaseApp, firebaseConfig.storageBucket));
    }
  }, [firebaseApp]);

  useEffect(() => {
    if (!firestore || !isMember || !teamId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const filesCol = collection(firestore, 'teams', teamId, 'files');
    const q = query(filesCol, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        const fetchedFiles = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ProjectFile));
        setFiles(fetchedFiles);
        setLoading(false);
        setError(null);
      },
      (err: FirestoreError) => {
        const permissionError = new FirestorePermissionError({
            path: filesCol.path,
            operation: 'list',
        });
        errorEmitter.emit('permission-error', permissionError);
        setError(err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [teamId, firestore, isMember]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    if (!user || !firestore || !teamId || !storage) {
        toast({ title: "Cannot Upload", description: "Services not available. Please try again.", variant: "destructive" });
        return;
    }
      
    // --- patched: improved upload guards & error handling ---
const file = e.target.files[0];
// Basic client-side validation
if (!file) {
  toast({ title: "No file selected", description: "Please select a file to upload." });
  return;
}

// ensure user is signed in
if (!user) {
  console.warn("Upload attempted without authenticated user.");
  toast({ title: "Sign in required", description: "You must sign in to upload files." });
  setIsUploading(false);
  return;
}

// ensure user is a team member (storage.rules require membership)
if (!isMember) {
  console.warn("User is not a member of team:", teamId);
  toast({ title: "Permission denied", description: "Only team members can upload files." });
  setIsUploading(false);
  return;
}

const filesCol = collection(firestore, 'teams', teamId, 'files');
const storageRefPath = `teams/${teamId}/${Date.now()}_${file.name}`;
const storageRefObj = ref(storage, storageRefPath);

try {
  // Step 1: Upload the file to Cloud Storage
  const uploadTask = await uploadBytes(storageRefObj, file);
  // Step 2: Get the public download URL
  const downloadURL = await getDownloadURL(uploadTask.ref);

  // Step 3: Create a Firestore doc entry for the file
  const newFile = {
    name: file.name,
    path: storageRefPath,
    url: downloadURL,
    uploaderId: user.uid,
    uploaderName: user.displayName || 'Unknown',
    createdAt: serverTimestamp()
  };
  await addDoc(filesCol, newFile);

  toast({ title: "Upload successful", description: `${file.name} uploaded.` });
} catch (err) {
  // Provide actionable messages for common error types
  console.error("Upload failed:", err);

  // Firebase Storage permission / auth errors often include 'Firebase' message strings
  const msg = (err && err.message) ? err.message : String(err || 'Unknown error');
  if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('unauthorized') || msg.toLowerCase().includes('auth')) {
    toast({ title: "Upload failed - permission denied", description: "Check that you are signed in and are a team member. (Storage rules might be blocking the upload.)" });
  } else {
    toast({ title: "Upload failed", description: msg });
  }
} finally {
  setIsUploading(false);
}
// --- end patched block ---

    } catch (error: any) {
        // Create and emit a contextual error for debugging security rules.
        const permissionError = new FirestorePermissionError({
            path: `teams/${teamId}`, // The resource being protected
            operation: 'write', // The operation being attempted on storage, but checked in firestore
            requestResourceData: { fileName: file.name, teamId: teamId }, // Include relevant data
        });
        errorEmitter.emit('permission-error', permissionError);
        
        // Update the toast to show a generic failure message to the user.
        uploadToast.update({ 
            id: uploadToast.id, 
            title: "Upload Failed", 
            description: "You do not have permission to upload files to this project.", 
            variant: 'destructive' 
        });

    } finally {
        setIsUploading(false);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    }
  };

  if (!isMember) {
    return (
        <Card className="h-96 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
                <Lock className="h-12 w-12 mx-auto mb-4"/>
                <p className="font-semibold">Files are for team members only.</p>
                <p>Join the team to access and share project files.</p>
            </div>
        </Card>
    )
  }
  
  if (!teamId && isMember) {
    return (
        <Card className="h-96 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
                <p>File sharing not available.</p>
                <p>This opportunity does not have file sharing enabled.</p>
            </div>
        </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Project Files</CardTitle>
        <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
        />
        <Button onClick={() => fileInputRef.current?.click()} disabled={isUploading || !!error || !storage}>
            {isUploading ? <LoadingSpinner className="h-4 w-4 mr-2"/> : <Upload className="h-4 w-4 mr-2"/>}
            Upload File
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? <div className="flex justify-center items-center h-24"><LoadingSpinner /></div> : 
         error ? (
             <div className="text-center text-destructive-foreground bg-destructive/80 p-4 rounded-md">
                <p>Error loading files.</p>
                <p className="text-sm">{error.message}</p>
             </div>
         ) : (
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Uploader</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {files.length === 0 ? (
                        <TableRow>
                            <TableCell colSpan={4} className="h-24 text-center">
                                No files have been uploaded yet.
                            </TableCell>
                        </TableRow>
                    ) : (
                        files.map(file => (
                            <TableRow key={file.id}>
                                <TableCell className="font-medium flex items-center gap-2"><File className="h-4 w-4 text-muted-foreground"/>{file.name}</TableCell>
                                <TableCell>{file.uploaderName}</TableCell>
                                <TableCell>{file.createdAt ? format(file.createdAt instanceof Date ? file.createdAt : file.createdAt.toDate(), 'PPP') : 'Just now'}</TableCell>
                                <TableCell className="text-right">
                                    <Button variant="ghost" size="icon" asChild disabled={!file.url}>
                                        <a href={file.url} target="_blank" rel="noopener noreferrer" download={file.name}>
                                            <Download className="h-4 w-4" />
                                        </a>
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))
                    )}
                </TableBody>
            </Table>
        )}
      </CardContent>
    </Card>
  );
}
