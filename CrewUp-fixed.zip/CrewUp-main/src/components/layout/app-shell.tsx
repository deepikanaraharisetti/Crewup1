'use client';

import { useRouter } from 'next/navigation';
import AppHeader from '@/components/layout/app-header';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarInset,
} from '@/components/ui/sidebar';
import Link from 'next/link';
import {
  Briefcase,
  FolderKanban,
  LayoutDashboard,
  LogOut,
  PlusSquare,
  Search,
  User,
} from 'lucide-react';
import { useUser, useAuth } from '@/firebase';
import { usePathname } from 'next/navigation';
import { signOut } from 'firebase/auth';

export default function AppShell({ children }: { children: React.ReactNode }) {
  const { user, isUserLoading: authLoading } = useUser();
  const auth = useAuth();
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    if (!auth) return;
    await signOut(auth);
    router.push('/login');
  };

  const navItems = [
    { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { href: '/explore', icon: Search, label: 'Explore' },
    { href: '/my-projects', icon: FolderKanban, label: 'My Projects' },
    { href: '/opportunities/create', icon: PlusSquare, label: 'New Opportunity' },
    { href: user ? `/users/${user.uid}` : '/profile', icon: User, label: 'My Profile' },
  ];

  const isNavItemActive = (href: string) => {
    // For dashboard, we want an exact match.
    if (href === '/dashboard') {
      return pathname === href;
    }
    // For other links, we want to match if the current path starts with the href.
    // This makes parent links active for child routes (e.g., /my-projects is active for /my-projects/some-id)
    return pathname.startsWith(href);
  };

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {navItems.map((item) => (
              <SidebarMenuItem key={item.href + item.label}>
                <SidebarMenuButton
                  asChild
                  isActive={isNavItemActive(item.href)}
                  tooltip={item.label}
                >
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter>
            <SidebarMenu>
                <SidebarMenuItem>
                    <SidebarMenuButton onClick={handleLogout} tooltip="Logout">
                        <LogOut />
                        <span>Logout</span>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
          <AppHeader />
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-auto bg-muted/40">
            {children}
          </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
