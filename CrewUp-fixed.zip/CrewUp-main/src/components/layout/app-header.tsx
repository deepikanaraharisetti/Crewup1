
'use client';

import Link from 'next/link';
import {
  Briefcase,
  Bell,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import UserNav from './user-nav';
import { useRouter } from 'next/navigation';
import { useFirestore, useUser } from '@/firebase';
import { useCollection } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import { Opportunity, JoinRequest } from '@/lib/types';
import { Badge } from '../ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useMemoFirebase } from '@/firebase/provider';
import React from 'react';

function getInitials(name: string | null | undefined): string {
    if (!name) return '??';
    return name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase();
}


function Notifications() {
    const { user } = useUser();
    
    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                    <Bell className="h-5 w-5" />
                    <span className="sr-only">Toggle notifications</span>
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-2" align="end">
                <div className="font-semibold p-2">Notifications</div>
                <div className="border-t border-muted -mx-2 my-1" />
                <div className="text-center text-sm text-muted-foreground p-4">
                    No new notifications.
                </div>
            </PopoverContent>
        </Popover>
    );
}

export default function AppHeader() {
  return (
    <header className="flex h-20 items-center gap-4 border-b bg-card px-4 md:px-6 sticky top-0 z-30">
      <SidebarTrigger />
       <div className="flex-1">
         <Link href="/dashboard" className="flex items-center gap-2 font-bold text-lg">
          <Briefcase className="w-6 h-6 text-primary" />
          <span className="hidden sm:inline-block">CrewUp</span>
        </Link>
      </div>

      <div className="flex items-center gap-2">
        <Notifications />
        <UserNav />
      </div>
    </header>
  );
}
