
'use client';

import { useState, KeyboardEvent } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { UserProfile } from '@/lib/types';
import { doc, setDoc } from 'firebase/firestore';
import { updateProfile } from 'firebase/auth';
import { useAuth, useFirestore, useUser, errorEmitter, FirestorePermissionError } from '@/firebase';
import { useToast } from '@/hooks/use-toast';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import LoadingSpinner from './loading-spinner';
import { Badge } from './ui/badge';
import { X } from 'lucide-react';

const profileSchema = z.object({
  displayName: z.string().min(1, 'Name is required'),
  bio: z.string().optional(),
  skills: z.array(z.string()).optional(),
  interests: z.array(z.string()).optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfileForm({ userProfile }: { userProfile: UserProfile }) {
  const router = useRouter();
  const { toast } = useToast();
  const { user: authUser } = useUser();
  const auth = useAuth();
  const firestore = useFirestore();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: userProfile.displayName || '',
      bio: userProfile.bio || '',
      skills: userProfile.skills || [],
      interests: userProfile.interests || [],
    },
  });

  const handleArrayInput = (e: KeyboardEvent<HTMLInputElement>, field: 'skills' | 'interests') => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const input = e.currentTarget;
      const newValue = input.value.trim();
      const currentValues = form.getValues(field) || [];
      if (newValue && !currentValues.includes(newValue)) {
        form.setValue(field, [...currentValues, newValue]);
        input.value = '';
      }
    }
  };

  const removeFromArray = (valueToRemove: string, field: 'skills' | 'interests') => {
    const currentValues = form.getValues(field) || [];
    form.setValue(field, currentValues.filter(value => value !== valueToRemove));
  };


  const onSubmit = async (data: ProfileFormValues) => {
    if (!authUser || !auth || !firestore) {
        toast({ title: "Error", description: "Cannot update profile. Services not available.", variant: "destructive" });
        return;
    };
    setIsLoading(true);

    const userDocRef = doc(firestore, 'users', authUser.uid);
    const profileData = {
      ...userProfile,
      ...data,
      uid: authUser.uid,
      email: authUser.email,
      photoURL: authUser.photoURL, // Keep existing photoURL
    };

    try {
      await updateProfile(authUser, {
        displayName: data.displayName,
      });

      await setDoc(userDocRef, profileData, { merge: true });

      toast({
        title: 'Profile Updated',
        description: 'Your profile has been successfully updated.',
      });
      router.push(`/users/${authUser.uid}`);
      router.refresh();

    } catch (error: any) {
        const permissionError = new FirestorePermissionError({
            path: userDocRef.path,
            operation: 'write',
            requestResourceData: profileData,
        });
        errorEmitter.emit('permission-error', permissionError);
        
        toast({
            title: 'Update Failed',
            description: 'Could not save profile. Please check permissions and try again.',
            variant: 'destructive',
        });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>This information will be displayed on your public profile.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="displayName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Display Name</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bio</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Tell us a little about yourself" className="resize-none" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Professional Details</CardTitle>
            <CardDescription>Highlight your skills and interests to find the right projects.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="skills"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Skills</FormLabel>
                  <FormControl>
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-2 min-h-[2.25rem] items-center">
                        {field.value?.map(skill => (
                          <Badge key={skill} variant="secondary" className="text-sm py-1 pl-3 pr-2">
                            {skill}
                            <button type="button" onClick={() => removeFromArray(skill, 'skills')} className="ml-2 rounded-full hover:bg-destructive/20 p-0.5">
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                      <Input
                        placeholder="Add a skill and press Enter"
                        onKeyDown={(e) => handleArrayInput(e, 'skills')}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="interests"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Interests</FormLabel>
                  <FormControl>
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-2 min-h-[2.25rem] items-center">
                        {field.value?.map(interest => (
                          <Badge key={interest} variant="secondary" className="text-sm py-1 pl-3 pr-2">
                            {interest}
                            <button type="button" onClick={() => removeFromArray(interest, 'interests')} className="ml-2 rounded-full hover:bg-destructive/20 p-0.5">
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                      <Input
                        placeholder="Add an interest and press Enter"
                        onKeyDown={(e) => handleArrayInput(e, 'interests')}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={isLoading}>
            {isLoading ? <LoadingSpinner className="h-4 w-4" /> : 'Save Changes'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
