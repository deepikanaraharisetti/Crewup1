
'use client';

import { useState, useEffect, useRef } from 'react';
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot, FirestoreError } from 'firebase/firestore';
import { useFirestore, useUser, errorEmitter, FirestorePermissionError } from '@/firebase';
import { ChatMessage, Opportunity } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import LoadingSpinner from './loading-spinner';
import { formatDistanceToNow } from 'date-fns';
import { Send, Lock } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';

interface OpportunityChatProps {
  opportunity: Opportunity;
  isMember: boolean;
}

export default function OpportunityChat({ opportunity, isMember }: OpportunityChatProps) {
  const { user } = useUser();
  const firestore = useFirestore();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<FirestoreError | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { teamId } = opportunity;

  useEffect(() => {
    if (!firestore || !isMember || !teamId) {
        setLoading(false);
        return;
    };

    setLoading(true);
    const messagesCol = collection(firestore, 'teams', teamId, 'messages');
    const q = query(messagesCol, orderBy('createdAt', 'asc'));

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        const fetchedMessages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ChatMessage));
        setMessages(fetchedMessages);
        setLoading(false);
        setError(null);
      },
      (err: FirestoreError) => {
        const permissionError = new FirestorePermissionError({
            path: messagesCol.path,
            operation: 'list',
            cause: err
        });
        errorEmitter.emit('permission-error', permissionError);
        setError(err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [teamId, firestore, isMember]);

  useEffect(() => {
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]');
        if (viewport) {
            viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !firestore || !teamId) return;

    const messagesCol = collection(firestore, 'teams', teamId, 'messages');
    const messageData = {
      text: newMessage,
      senderId: user.uid,
      senderName: user.displayName,
      senderPhotoURL: user.photoURL,
      createdAt: serverTimestamp(),
    };
    
    addDoc(messagesCol, messageData)
        .catch((serverError) => {
             const permissionError = new FirestorePermissionError({
                path: messagesCol.path,
                operation: 'create',
                requestResourceData: messageData,
                cause: serverError
            });
            errorEmitter.emit('permission-error', permissionError);
        });

    setNewMessage('');
  };

  const getInitials = (name: string | null | undefined): string => {
    if (!name) return '??';
    return name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase();
  };

  if (!isMember) {
    return (
        <Card className="h-[32rem] flex items-center justify-center">
            <div className="text-center text-muted-foreground">
                <Lock className="h-12 w-12 mx-auto mb-4"/>
                <p className="font-semibold">Chat is for team members only.</p>
                <p>Join the team to participate in the conversation.</p>
            </div>
        </Card>
    )
  }
  
  if (!teamId && isMember) {
    return (
        <Card className="h-[32rem] flex items-center justify-center">
             <div className="text-center text-muted-foreground">
                <p>Chat not available.</p>
                <p>This opportunity does not have a team chat enabled.</p>
            </div>
        </Card>
    )
  }

  return (
    <Card className="h-[32rem] flex flex-col">
      <CardHeader>
        <CardTitle>Team Chat</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0">
        <ScrollArea className="h-full" ref={scrollAreaRef}>
          <div className="p-6 space-y-4">
            {loading ? (
              <div className="flex justify-center items-center h-full pt-16">
                <LoadingSpinner />
              </div>
            ) : error ? (
                <div className="text-center text-destructive-foreground bg-destructive/80 p-4 rounded-md">
                    <p>Error loading chat.</p>
                    <p className="text-sm">{error.message}</p>
                </div>
            ) : messages.length === 0 ? (
                <div className="text-center text-muted-foreground pt-16">
                    <p>No messages yet.</p>
                    <p>Be the first to say hello!</p>
                </div>
            ) : (
              messages.map(msg => (
                <div key={msg.id} className="flex items-start gap-3">
                  <Avatar>
                    <AvatarImage src={msg.senderPhotoURL || ''} />
                    <AvatarFallback>{getInitials(msg.senderName)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-baseline gap-2">
                      <p className="font-semibold">{msg.senderName}</p>
                      <p className="text-xs text-muted-foreground">
                        {msg.createdAt ? formatDistanceToNow(msg.createdAt.toDate(), { addSuffix: true }) : 'sending...'}
                      </p>
                    </div>
                    <p className="text-sm">{msg.text}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="p-4 border-t">
        <form onSubmit={handleSendMessage} className="flex w-full items-center space-x-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            autoComplete="off"
            disabled={loading || !!error}
          />
          <Button type="submit" size="icon" disabled={!newMessage.trim() || loading || !!error}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
