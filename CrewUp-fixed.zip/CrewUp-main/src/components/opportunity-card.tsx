
import Link from 'next/link';
import { Opportunity, UserProfile } from '@/lib/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Users, MoreVertical, Trash2 } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { useUser, useFirestore, errorEmitter, FirestorePermissionError } from '@/firebase';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useState } from 'react';
import LoadingSpinner from './loading-spinner';
import { writeBatch, doc } from 'firebase/firestore';

interface OpportunityCardProps {
  opportunity: Opportunity;
  onDeleted?: (opportunityId: string) => void;
}

function getInitials(name: string | null | undefined): string {
  if (!name) return '??';
  return name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase();
}

function TeamMemberPopover({ user }: { user: UserProfile }) {
    return (
        <Popover>
            <PopoverTrigger asChild>
                <Avatar className="h-8 w-8 border-2 border-card cursor-pointer">
                    <AvatarImage src={user.photoURL || undefined} />
                    <AvatarFallback>{getInitials(user.displayName)}</AvatarFallback>
                </Avatar>
            </PopoverTrigger>
            <PopoverContent className="w-64">
                <div className="flex items-center gap-3">
                    <Avatar>
                        <AvatarImage src={user.photoURL || undefined} />
                        <AvatarFallback>{getInitials(user.displayName)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <Link href={`/users/${user.uid}`} className="font-semibold hover:underline">{user.displayName}</Link>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                </div>
            </PopoverContent>
        </Popover>
    )
}

function DeleteConfirmationDialog({ opportunity, userId, onDeleted, open, onOpenChange }: { opportunity: Opportunity, userId: string, onDeleted: (id: string) => void, open: boolean, onOpenChange: (open: boolean) => void }) {
    const { toast } = useToast();
    const [isDeleting, setIsDeleting] = useState(false);
    const firestore = useFirestore();

    const handleDelete = async () => {
        if (!firestore) {
            toast({ title: "Error", description: "Firestore not available.", variant: "destructive" });
            return;
        }

        setIsDeleting(true);
        
        try {
            const batch = writeBatch(firestore);

            // 1. Delete the opportunity document
            const opportunityRef = doc(firestore, 'opportunities', opportunity.id);
            batch.delete(opportunityRef);

            // 2. Delete the associated team document, if it exists
            if (opportunity.teamId) {
                const teamRef = doc(firestore, 'teams', opportunity.teamId);
                batch.delete(teamRef);
            }

            // Note: Client-side SDKs cannot recursively delete sub-collections.
            // The joinRequests, messages, and files sub-collections will be orphaned.
            // This is a limitation of Firestore security rules from the client.
            // For a production app, a Cloud Function would be needed to clean these up.
            // But for this fix, ensuring the primary documents are deleted is the goal.

            await batch.commit();

            toast({
                title: "Opportunity Deleted",
                description: "The opportunity and its team have been deleted.",
            });
            onDeleted(opportunity.id);

        } catch (error: any) {
            const permissionError = new FirestorePermissionError({
                path: `opportunities/${opportunity.id}`,
                operation: 'delete',
            });
            errorEmitter.emit('permission-error', permissionError);

            toast({
                title: "Deletion Failed",
                description: "You do not have permission to delete this opportunity.",
                variant: "destructive",
            });
        } finally {
            setIsDeleting(false);
            onOpenChange(false);
        }
    };

    return (
        <AlertDialog open={open} onOpenChange={onOpenChange}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete the opportunity and its associated team. Sub-collections like chats may be orphaned.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        {isDeleting ? <LoadingSpinner className='h-4 w-4' /> : 'Delete'}
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}


export default function OpportunityCard({ opportunity, onDeleted = () => {} }: OpportunityCardProps) {
  const { user } = useUser();
  const isOwner = user?.uid === opportunity.ownerId;
  const [dialogOpen, setDialogOpen] = useState(false);

  const ownerProfile: UserProfile = {
      uid: opportunity.ownerId,
      displayName: opportunity.ownerName,
      photoURL: opportunity.ownerPhotoURL,
      email: '' // Not available in opportunity data
  }

  return (
    <Card className="h-full flex flex-col transition-all duration-300 hover:shadow-lg hover:border-primary/50 group">
        <CardHeader>
            <div className="flex justify-between items-start">
                <CardTitle className="text-lg font-semibold leading-snug">
                <Link href={`/opportunities/${opportunity.id}`} className="hover:text-primary stretched-link">{opportunity.title}</Link>
                </CardTitle>
                {isOwner && (
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7 -mr-2 -mt-1 flex-shrink-0 z-10">
                                <MoreVertical className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem className="text-destructive" onSelect={(e) => { e.preventDefault(); setDialogOpen(true); }}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                )}
            </div>
            <CardDescription className="text-sm">
                by <Link href={`/users/${opportunity.ownerId}`} className="font-medium text-card-foreground hover:underline">{opportunity.ownerName}</Link>
            </CardDescription>
        </CardHeader>
        <CardContent className="flex-grow space-y-3">
            <p className="text-sm text-muted-foreground line-clamp-3">
            {opportunity.description}
            </p>
            <div className="flex flex-wrap gap-1 pt-2">
            {opportunity.requiredSkills.slice(0, 3).map(skill => (
                <Badge key={skill} variant="secondary">{skill}</Badge>
            ))}
            {opportunity.requiredSkills.length > 3 && (
                <Badge variant="outline">+{opportunity.requiredSkills.length - 3}</Badge>
            )}
            </div>
        </CardContent>
        <CardFooter className="p-4 flex justify-between items-center text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
            <Users className="h-4 w-4"/>
            <span>{opportunity.teamMembers.length + 1} Member{opportunity.teamMembers.length + 1 === 1 ? '' : 's'}</span>
            </div>
            <div className="flex items-center -space-x-2">
            <TeamMemberPopover user={ownerProfile} />
            {opportunity.teamMembers.slice(0,2).map(member => (
                <TeamMemberPopover key={member.uid} user={member} />
            ))}
            {opportunity.teamMembers.length > 2 && (
                <Avatar className="h-8 w-8 border-2 border-card bg-muted-foreground/80 text-background">
                    <AvatarFallback className="text-xs font-semibold">+{opportunity.teamMembers.length - 2}</AvatarFallback>
                </Avatar>
            )}
            </div>
        </CardFooter>
        {user && <DeleteConfirmationDialog opportunity={opportunity} userId={user.uid} onDeleted={onDeleted} open={dialogOpen} onOpenChange={setDialogOpen} />}
    </Card>
  );
}
