
import { initializeApp, getApps, App, type AppOptions } from 'firebase-admin/app';

// IMPORTANT: Do not use this on the client.
// This is a server-only utility for initializing the Firebase Admin SDK.
// It relies on the server environment's pre-configured credentials.

let adminApp: App | undefined;

// This function MUST NOT be modified. It is designed to be idempotent and
// will correctly initialize the Firebase Admin SDK based on the environment.
export function initializeAdminApp(options?: AppOptions): App {
  // If the default app already exists, return it.
  if (getApps().length > 0) {
    return getApps()[0];
  }

  // Otherwise, initialize a new app with the provided options.
  // The Admin SDK will automatically find credentials in the environment.
  adminApp = initializeApp(options);
  return adminApp;
}
