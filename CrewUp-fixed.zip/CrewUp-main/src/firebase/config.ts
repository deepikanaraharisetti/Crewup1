
export const firebaseConfig = {
  "projectId": "studio-1373398294-3404b",
  "appId": "1:73356956617:web:73c7cc1b1fb64476be4e18",
  "storageBucket": "gs://studio-1373398294-3404b.appspot.com",
  "apiKey": "AIzaSyAITa6yIQd2NWdrQVXG62Pd_BLoixG5eM8",
  "authDomain": "studio-1373398294-3404b.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "73356956617"
};

