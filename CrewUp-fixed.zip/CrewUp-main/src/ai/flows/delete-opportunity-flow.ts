
'use server';

/**
 * @fileOverview A flow to delete an opportunity and its associated data.
 *
 * - deleteOpportunity - Deletes an opportunity, its team, and all sub-collections.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';
import { initializeAdminApp } from '@/firebase/admin';
import { DeleteOpportunityInputSchema, DeleteOpportunityInput } from '@/lib/types';
import { getFirestore } from 'firebase-admin/firestore';

// This function is exported and can be called from the client.
export async function deleteOpportunity(input: DeleteOpportunityInput): Promise<{ success: boolean; error?: string }> {
  return deleteOpportunityFlow(input);
}


// Helper to recursively delete a collection and its subcollections
async function deleteCollection(db: FirebaseFirestore.Firestore, collectionPath: string, batchSize: number) {
    const collectionRef = db.collection(collectionPath);
    const query = collectionRef.orderBy('__name__').limit(batchSize);

    return new Promise<void>((resolve, reject) => {
        deleteQueryBatch(db, query, resolve).catch(reject);
    });
}

async function deleteQueryBatch(db: FirebaseFirestore.Firestore, query: FirebaseFirestore.Query, resolve: () => void) {
    const snapshot = await query.get();

    const batchSize = snapshot.size;
    if (batchSize === 0) {
        resolve();
        return;
    }

    const batch = db.batch();
    snapshot.docs.forEach((doc) => {
        batch.delete(doc.ref);
    });
    await batch.commit();

    process.nextTick(() => {
        deleteQueryBatch(db, query, resolve);
    });
}


const deleteOpportunityFlow = ai.defineFlow(
  {
    name: 'deleteOpportunityFlow',
    inputSchema: DeleteOpportunityInputSchema,
    outputSchema: z.object({ success: z.boolean(), error: z.string().optional() }),
  },
  async ({ opportunityId, userId }) => {
    try {
      // Initialize the admin app to run with full privileges.
      const adminApp = initializeAdminApp();
      const firestore = getFirestore(adminApp);
      
      const opportunityRef = firestore.collection('opportunities').doc(opportunityId);
      const opportunitySnap = await opportunityRef.get();

      if (!opportunitySnap.exists) {
        console.log(`Opportunity ${opportunityId} does not exist. Assuming already deleted.`);
        return { success: true }; 
      }

      const opportunityData = opportunitySnap.data();
      
      // CRITICAL: Verify the user requesting deletion is the owner before proceeding.
      if (opportunityData?.ownerId !== userId) {
          throw new Error('Permission denied: User is not the owner of this opportunity.');
      }

      const teamId = opportunityData?.teamId;
      
      const batch = firestore.batch();
      
      // Delete join requests sub-collection for the opportunity
      await deleteCollection(firestore, `opportunities/${opportunityId}/joinRequests`, 50);

      // Delete associated Team and its sub-collections (files, messages)
      if (teamId) {
        // Delete Firestore documents for sub-collections ('files', 'messages')
        await deleteCollection(firestore, `teams/${teamId}/files`, 50);
        await deleteCollection(firestore, `teams/${teamId}/messages`, 50);
        
        // Delete the team document itself
        console.log(`Deleting team document: ${teamId}`);
        const teamRef = firestore.collection('teams').doc(teamId);
        batch.delete(teamRef);
      }
      
      // Finally, delete the opportunity document itself
      console.log(`Deleting opportunity document: ${opportunityId}`);
      batch.delete(opportunityRef);

      await batch.commit();

      console.log(`Successfully deleted opportunity ${opportunityId} and all associated data.`);
      
      return { success: true };

    } catch (error: any) {
        console.error('CRITICAL ERROR in deleteOpportunityFlow:', error);
        let errorMessage = 'An unexpected server error occurred during deletion.';
        if (error.code === 7 || (error.message && (error.message.includes('permission-denied') || error.message.includes('Permission denied')))) {
            errorMessage = 'Server permission issue. The service account may lack required IAM roles like "Cloud Datastore User". Please check your GCP IAM settings.'
        } else if (error.message) {
            errorMessage = error.message;
        }
        return { success: false, error: errorMessage };
    }
  }
);
