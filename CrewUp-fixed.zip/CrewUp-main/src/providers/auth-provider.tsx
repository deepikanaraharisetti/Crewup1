
'use client';

import React from 'react';
import { useUser } from '@/firebase';
import LoadingSpinner from '@/components/loading-spinner';

// This provider is simpler. Its only job is to show a loading spinner
// until the main `useUser` hook reports that authentication is no longer loading.
// It doesn't need its own context or state.
export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const { isUserLoading } = useUser();

  // While the authentication state is being determined, show a full-screen loader.
  if (isUserLoading) {
    return <LoadingSpinner fullScreen />;
  }

  // Once loading is complete, render the children.
  return <>{children}</>;
};

